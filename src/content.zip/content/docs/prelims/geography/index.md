---
title: Prelims Geography
description: ""
category: Prelims
order: 4
lastModified: 2025-12-07
version: ""
image: ""
imageAlt: ""
hideCoverImage: false
hideTOC: false
draft: false
noIndex: false
featured: false
aliases:
  - Geography
---
